using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

public partial class MainForm : Form
{
    private Label lblStatus;
    private TextBox txtPassword;
    private Button btnCreatePassword;
    private ProgressBar progressBar;
    private string passwordFilePath;

    public MainForm()
    {
        InitializeComponent();
        CheckPasswordFile();
    }

    private void InitializeComponent()
    {
        this.Text = "Passcrypt - Password Manager";
        this.Size = new Size(500, 300);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;

        // Définir le chemin du fichier
        passwordFilePath = Path.Combine(Application.StartupPath, "pass", "ultimatepass.txt");

        // Label de statut
        lblStatus = new Label();
        lblStatus.Location = new Point(20, 30);
        lblStatus.Size = new Size(450, 40);
        lblStatus.Font = new Font("Arial", 12, FontStyle.Bold);
        lblStatus.TextAlign = ContentAlignment.MiddleCenter;
        this.Controls.Add(lblStatus);

        // TextBox pour le mot de passe (masqué)
        txtPassword = new TextBox();
        txtPassword.Location = new Point(50, 100);
        txtPassword.Size = new Size(400, 25);
        txtPassword.UseSystemPasswordChar = true;
        txtPassword.Font = new Font("Arial", 10);
        txtPassword.Visible = false;
        this.Controls.Add(txtPassword);

        // Bouton pour créer le mot de passe
        btnCreatePassword = new Button();
        btnCreatePassword.Text = "Create Secure Password";
        btnCreatePassword.Location = new Point(150, 150);
        btnCreatePassword.Size = new Size(200, 40);
        btnCreatePassword.Font = new Font("Arial", 10, FontStyle.Bold);
        btnCreatePassword.BackColor = Color.LightBlue;
        btnCreatePassword.Click += new EventHandler(btnCreatePassword_Click);
        btnCreatePassword.Visible = false;
        this.Controls.Add(btnCreatePassword);

        // Barre de progression
        progressBar = new ProgressBar();
        progressBar.Location = new Point(50, 200);
        progressBar.Size = new Size(400, 25);
        progressBar.Style = ProgressBarStyle.Continuous;
        progressBar.Visible = false;
        this.Controls.Add(progressBar);
    }

    private void CheckPasswordFile()
    {
        if (File.Exists(passwordFilePath))
        {
            lblStatus.Text = "File found";
            lblStatus.ForeColor = Color.Green;
            
            // Fermer automatiquement après 2 secondes
            Timer timer = new Timer();
            timer.Interval = 2000;
            timer.Tick += (s, e) => { timer.Stop(); this.Close(); };
            timer.Start();
        }
        else
        {
            lblStatus.Text = "Password file not found.\nPlease enter a strong password:";
            lblStatus.ForeColor = Color.Red;
            txtPassword.Visible = true;
            btnCreatePassword.Visible = true;
        }
    }

    private async void btnCreatePassword_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtPassword.Text) || txtPassword.Text.Length < 8)
        {
            MessageBox.Show("Password must be at least 8 characters long.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        // Masquer les contrôles et afficher la barre de progression
        txtPassword.Visible = false;
        btnCreatePassword.Visible = false;
        progressBar.Visible = true;
        lblStatus.Text = "Encryption in progress...";
        lblStatus.ForeColor = Color.Blue;

        // Effectuer le double cryptage avec barre de progression
        await PerformDoubleEncryption(txtPassword.Text);
    }

    private async Task PerformDoubleEncryption(string password)
    {
        try
        {
            // Créer le dossier pass s'il n'existe pas
            string passDir = Path.GetDirectoryName(passwordFilePath);
            if (!Directory.Exists(passDir))
            {
                Directory.CreateDirectory(passDir);
            }

            // Première phase : Cryptage AES-256
            progressBar.Value = 10;
            lblStatus.Text = "Phase 1: AES-256 encryption...";
            await Task.Delay(500);

            string firstEncryption = EncryptAES256(password);
            progressBar.Value = 30;
            await Task.Delay(500);

            // Deuxième phase : Cryptage SHA-512 + Salt
            lblStatus.Text = "Phase 2: Adding salt and SHA-512 hashing...";
            progressBar.Value = 50;
            await Task.Delay(500);

            string secondEncryption = EncryptSHA512WithSalt(firstEncryption);
            progressBar.Value = 70;
            await Task.Delay(500);

            // Troisième phase : Conversion en binaire
            lblStatus.Text = "Phase 3: Converting to binary format...";
            progressBar.Value = 85;
            await Task.Delay(500);

            string binaryData = ConvertToBinary(secondEncryption);
            progressBar.Value = 95;
            await Task.Delay(300);

            // Sauvegarde finale
            lblStatus.Text = "Finalizing and saving...";
            File.WriteAllText(passwordFilePath, binaryData);
            progressBar.Value = 100;
            await Task.Delay(500);

            // Succès
            lblStatus.Text = "Secure password created successfully!";
            lblStatus.ForeColor = Color.Green;
            
            // Fermer automatiquement après 2 secondes
            Timer timer = new Timer();
            timer.Interval = 2000;
            timer.Tick += (s, e) => { timer.Stop(); this.Close(); };
            timer.Start();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error during encryption: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private string EncryptAES256(string plainText)
    {
        using (Aes aesAlg = Aes.Create())
        {
            aesAlg.KeySize = 256;
            aesAlg.GenerateKey();
            aesAlg.GenerateIV();

            ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

            using (MemoryStream msEncrypt = new MemoryStream())
            {
                using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                {
                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                    {
                        swEncrypt.Write(plainText);
                    }
                }
                byte[] encrypted = msEncrypt.ToArray();
                // Combine IV + Key + encrypted data
                byte[] result = new byte[aesAlg.IV.Length + aesAlg.Key.Length + encrypted.Length];
                Array.Copy(aesAlg.IV, 0, result, 0, aesAlg.IV.Length);
                Array.Copy(aesAlg.Key, 0, result, aesAlg.IV.Length, aesAlg.Key.Length);
                Array.Copy(encrypted, 0, result, aesAlg.IV.Length + aesAlg.Key.Length, encrypted.Length);
                return Convert.ToBase64String(result);
            }
        }
    }

    private string EncryptSHA512WithSalt(string input)
    {
        // Générer un salt aléatoire
        byte[] salt = new byte[32];
        using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
        {
            rng.GetBytes(salt);
        }

        // Combiner input et salt
        byte[] inputBytes = Encoding.UTF8.GetBytes(input);
        byte[] combinedBytes = new byte[inputBytes.Length + salt.Length];
        Array.Copy(inputBytes, 0, combinedBytes, 0, inputBytes.Length);
        Array.Copy(salt, 0, combinedBytes, inputBytes.Length, salt.Length);

        // Hash SHA-512
        using (SHA512 sha512 = SHA512.Create())
        {
            byte[] hashBytes = sha512.ComputeHash(combinedBytes);
            
            // Combiner salt + hash pour le stockage
            byte[] result = new byte[salt.Length + hashBytes.Length];
            Array.Copy(salt, 0, result, 0, salt.Length);
            Array.Copy(hashBytes, 0, result, salt.Length, hashBytes.Length);
            
            return Convert.ToBase64String(result);
        }
    }

    private string ConvertToBinary(string input)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(input);
        StringBuilder binary = new StringBuilder();
        
        foreach (byte b in bytes)
        {
            binary.Append(Convert.ToString(b, 2).PadLeft(8, '0'));
        }
        
        return binary.ToString();
    }

    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
} 